module.exports = async (client) => {
  console.log(`[API] Logged in as ${client.user.username}`);
  await client.user.setActivity("LoFi Music",{ type: 'PLAYING'});
};